Prerequisite:
```bash
          sudo apt-get install -y libfontconfig1-dev pkg-config
```

You need a valid IIT-Delhi email address to be able to test the forgot-password feature
Please run ./config.sh to generate one
